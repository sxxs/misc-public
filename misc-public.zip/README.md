# misc-public

Public projects and demos

## 🎮 Projects

### [Multiplication Troll Game](multiplication-troll-game/)

Ein Retro-Style Multiplizierungsspiel zum Üben des kleinen 1x1 mit fiesen Troll-Mechaniken!

**[▶️ Spiel starten](https://sxxs.github.io/misc-public/multiplication-troll-game/)**

- Retro-Pixel-Grafik mit Strichmännchen
- Aufgaben ändern sich spontan beim Tippen
- Mobile-optimiert
- Orange/Teal-Farbpalette

---

© 2025 - Alle Projekte für Bildungszwecke
